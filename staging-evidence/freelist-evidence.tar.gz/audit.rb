require 'json'
require 'digest'

# check 在原始证据不满足约定时中止报告，不将缺失或失败场次算作通过。
def check(condition, message)
  raise message unless condition
end

root=ARGV.fetch(0)
partial=ARGV.include?('--partial')
check(File.read(File.join(root,'exit-code')).strip=='0','runner failed or unfinished') unless partial
expected=[]
[[300000,0],[600000,0],[600000,200]].each do |n,rate|
  (1..3).each { |round| %w[baseline freelist].each { |variant| expected << "n#{n}-rate#{rate}-r#{round}-#{variant}" } }
end
expected.select! { |name| File.file?(File.join(root,'results',name,'result.json')) && File.file?(File.join(root,'results',name,'exit-code')) } if partial
check(!expected.empty?,'no completed cases to audit')
image=JSON.parse(File.read(File.join(root,'image-inspect.json')))[0].fetch('Id')
expected.each do |name|
  path=File.join(root,'results',name)
  r=JSON.parse(File.read(File.join(path,'result.json')))
  check(File.read(File.join(path,'exit-code')).strip=='0',"#{name}: exit")
  match=/n(\d+)-rate(\d+)-r(\d+)-(baseline|freelist)/.match(name)
  n,rate=match[1].to_i,match[2].to_i
  seed=JSON.parse(File.read(File.join(root,'seeds',n.to_s,'seed.json')))
  check(r.fetch('keys')==n && r.fetch('rate')==rate,"#{name}: scenario identity")
  check(r.fetch('checked_fixture_keys')==n,"#{name}: full fixture scan")
  check(r.fetch('db_size_before')==seed.fetch('db_size'),"#{name}: initial db bytes")
  check(r.fetch('hash_before')==seed.fetch('hash'),"#{name}: initial hash")
  check(r.fetch('hash_after')==r.fetch('restart_hash'),"#{name}: restart hash")
  check(rate!=0 || r.fetch('hash_after')==r.fetch('hash_before'),"#{name}: idle hash")
  check(r.fetch('request_errors')==0 && !r.key?('defrag_error'),"#{name}: request failure")
  lifecycle=File.readlines(File.join(path,'server.jsonl')).map { |line|JSON.parse(line) }
  check(lifecycle.count { |event|event['msg']=='starting an etcd server' }==2,"#{name}: initial start and restart")
  check(lifecycle.count { |event|event['msg']=='ready to serve client requests' }==2,"#{name}: both members ready")
  d=JSON.parse(File.read(File.join(path,'container-after.json')))[0]
  check(d.fetch('Image')==image && d.dig('State','ExitCode')==0 && !d.dig('State','OOMKilled'),"#{name}: runtime identity/state")
  check(d.dig('Config','Entrypoint')==["/#{match[4]}"],"#{name}: binary selection")
  check(d.dig('HostConfig','NetworkMode')=='none',"#{name}: network namespace")
  check(File.read(File.join(path,'cgroup-memory-max')).strip=='34359738368',"#{name}: actual memory limit")
  check(File.read(File.join(path,'cgroup-memory-swap-max')).strip=='0',"#{name}: actual swap limit")
  check(File.read(File.join(path,'cgroup-cpuset-cpus-effective')).strip=='16,18,20,22',"#{name}: actual cpuset")
  io=File.read(File.join(path,'cgroup-io-max'))
  %w[8:0 rbps=104857600 wbps=104857600 riops=4000 wiops=4000].each { |term| check(io.include?(term),"#{name}: actual IO #{term}") }
  samples=File.readlines(File.join(path,'requests.jsonl')).map { |line| JSON.parse(line) }
  check(samples.all? { |s|s.fetch('Error')=='' },"#{name}: raw request errors")
  get=samples.select { |s|s['Kind']=='get' && s['Start']>=r['started_ns'] && s['Start']<=r['ended_ns'] }.map { |s|s.fetch('MS') }.sort
  check(!get.empty? && get.size==r.fetch('during_get_samples'),"#{name}: during sample count")
  check((get[(get.size*99+99)/100-1]-r.fetch('during_get_p99_ms')).abs<1e-9,"#{name}: raw P99 replay")
  check((get.max-r.fetch('during_get_max_ms')).abs<1e-9,"#{name}: raw max replay")
  # Go 的 Sub 使用单调时钟，UnixNano 使用壁钟；允许二者读取/校准的亚毫秒差异。
  check((r.fetch('defrag_ms')-(r.fetch('ended_ns')-r.fetch('started_ns'))/1e6).abs<0.1,"#{name}: RPC timing")
end
filename=partial ? 'partial-audit.json' : 'audit.json'
File.write(File.join(root,filename),JSON.pretty_generate({'status'=>partial ? 'partial-checked-not-final' : 'passed','cases'=>expected.size,'checks'=>['binary and container identity','real cgroup limits','seed bytes and hash','fixture full scan assertions','ACK reconciliation assertions','restart hash','raw RPC error and latency replay'],'source'=>Digest::SHA256.file(__FILE__).hexdigest})+"\n")
puts "#{partial ? 'PARTIAL CHECK' : 'PASS'}: #{expected.size} cases; identities, limits, correctness assertions, restart and raw request statistics"
