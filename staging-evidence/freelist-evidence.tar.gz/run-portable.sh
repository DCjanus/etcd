#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "$0")"
exec > >(tee -a runner.log) 2>&1
trap 'rc=$?; echo "$rc" > exit-code; date -Is; exit "$rc"' EXIT
exec 9>experiment.lock
flock -n 9
image=etcd-freelist-upstream:20261030
prefix=etcd-freelist-20261030
mkdir -p results seeds
sha256sum -c binaries.sha256
sudo docker build --network none -t "$image" .
sudo docker image inspect "$image" > image-inspect.json
findmnt -T "$PWD" > filesystem.txt
lscpu > lscpu.txt
uname -a > kernel.txt
device=$(findmnt -n -o SOURCE -T "$PWD")
parent=$(lsblk -n -o PKNAME "$device" | head -1)
if [[ -n "$parent" ]]; then device="/dev/$parent"; fi
common=(--network none --log-driver journald --cpuset-cpus 16,18,20,22 --memory 32g --memory-swap 32g --pids-limit 512 --device-read-bps "$device:100mb" --device-write-bps "$device:100mb" --device-read-iops "$device:4000" --device-write-iops "$device:4000" --label experiment="$prefix" --mount "type=bind,src=$PWD,dst=/lab")

# run_container 为每场保存容器身份、实际 cgroup 和真实退出状态。
run_container() {
 local name=$1 binary=$2 output=$3
 shift 3
 mkdir -p "$output"
 sudo docker create --name "$name" "${common[@]}" --entrypoint "/$binary" "$image" "$@" > "$output/container-id"
 sudo docker inspect "$name" > "$output/container-before.json"
 sudo docker start "$name" > /dev/null
 local pid group
 pid=$(sudo docker inspect --format '{{.State.Pid}}' "$name")
 group=$(sudo awk -F: '$1==0{print $3}' "/proc/$pid/cgroup")
 for f in memory.max memory.swap.max memory.events cpu.max cpuset.cpus.effective io.max; do
   sudo cat "/sys/fs/cgroup$group/$f" > "$output/cgroup-${f//./-}" || true
 done
 local rc
 rc=$(sudo docker wait "$name")
 echo "$rc" > "$output/exit-code"
 sudo docker inspect "$name" > "$output/container-after.json"
 sudo docker logs "$name" > "$output/stdout.log" 2>&1
 sudo docker rm "$name" > /dev/null
 if [[ "$rc" != 0 ]]; then cat "$output/stdout.log"; return 1; fi
}

echo "$(date -Is) smoke: real seed, defrag RPC, full scan, restart/hash"
run_container "$prefix-smoke-seed" baseline "seeds/smoke" -mode seed -dir /lab/seeds/smoke/data -out /lab/seeds/smoke -keys 1000
for variant in baseline freelist; do
 mkdir -p "results/smoke-$variant"
 sudo cp -a "seeds/smoke/data" "results/smoke-$variant/data"
 run_container "$prefix-smoke-$variant" "$variant" "results/smoke-$variant" -mode run -dir "/lab/results/smoke-$variant/data" -out "/lab/results/smoke-$variant" -keys 1000 -rate 20
done

for n in 300000 600000; do
 echo "$(date -Is) preparing seed $n"
 run_container "$prefix-seed-$n" baseline "seeds/$n" -mode seed -dir "/lab/seeds/$n/data" -out "/lab/seeds/$n" -keys "$n"
 sudo sha256sum "seeds/$n/data/member/snap/db" > "seeds/$n/db.sha256"
 cat "seeds/$n/seed.json"
done

for spec in '300000 0' '600000 0' '600000 200'; do
 read -r n rate <<< "$spec"
 for round in 1 2 3; do
   if [[ $round == 2 ]]; then order='freelist baseline'; else order='baseline freelist'; fi
   for variant in $order; do
     caseid="n$n-rate$rate-r$round-$variant"
     echo "$(date -Is) starting $caseid"
     mkdir -p "results/$caseid"
     sudo cp -a --reflink=auto "seeds/$n/data" "results/$caseid/data"
     run_container "$prefix-$caseid" "$variant" "results/$caseid" -mode run -dir "/lab/results/$caseid/data" -out "/lab/results/$caseid" -keys "$n" -rate "$rate"
     cat "results/$caseid/result.json"
     # 删除当前场次可再生的数据副本，保留原始日志、校验结果与不可变 seed。
     sudo rm -rf -- "$PWD/results/$caseid/data"
   done
 done
done
echo "$(date -Is) ALL CASES COMPLETED"
