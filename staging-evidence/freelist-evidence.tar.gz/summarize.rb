require 'json'

# milliseconds 将 etcd 的 duration 字符串或秒数转换成毫秒。
def milliseconds(value)
  return value*1000 if value.is_a?(Numeric)
  units={'h'=>3600000.0,'m'=>60000.0,'s'=>1000.0,'ms'=>1.0,'µs'=>0.001,'us'=>0.001,'ns'=>0.000001}
  value.scan(/([\d.]+)(ms|µs|us|ns|h|m|s)/).sum { |number,unit| number.to_f*units.fetch(unit) }
end

# median 计算逐场指标的中位数，不把不同场次请求混为一个分位数。
def median(values)
  v=values.sort
  return nil if v.empty?
  (v[(v.size-1)/2]+v[v.size/2])/2.0
end

root=ARGV.fetch(0)
rows=[]
Dir.glob(File.join(root,'results/n*/result.json')).sort.each do |path|
  result=JSON.parse(File.read(path))
  name=File.basename(File.dirname(path))
  match=/n(\d+)-rate(\d+)-r(\d+)-(baseline|freelist)/.match(name)
  raise "invalid name #{name}" unless match
  raise "failed case #{name}" unless File.read(File.join(File.dirname(path),'exit-code')).strip=='0' && result.fetch('request_errors')==0 && !result.key?('defrag_error')
  logs=File.readlines(File.join(File.dirname(path),'server.jsonl')).filter_map { |line| JSON.parse(line) rescue nil }
  phase=logs.select { |row| row['msg']=='freelist-ab-stage' }.to_h { |row| [row.fetch('phase'),milliseconds(row.fetch('duration'))] }
  stw=logs.select { |row| row['msg']=='non-blocking defragmentation' }
  raise "non-blocking event count #{name}" unless stw.size==1
  row={'name'=>name,'keys'=>match[1].to_i,'rate'=>match[2].to_i,'round'=>match[3].to_i,'variant'=>match[4], 'reopen_ms'=>phase.fetch('reopen'),'stw_ms'=>milliseconds(stw[0].fetch('stopTheWorldDuration'))}.merge(result)
  samples=File.readlines(File.join(File.dirname(path),'requests.jsonl')).map { |line| JSON.parse(line) }
  writes=samples.count do |sample|
    completed=sample['Start']+(sample.fetch('MS')*1e6).round
    sample['Kind']=='put' && sample['Error']=='' && completed>=result['started_ns'] && completed<=result['ended_ns']
  end
  row['during_put_completions']=writes
  row['during_put_ops_s']=writes/(result.fetch('defrag_ms')/1000.0)
  rows<<row
end
groups=rows.group_by { |r| [r['keys'],r['rate'],r['variant']] }.map do |key,entries|
  {'keys'=>key[0],'rate'=>key[1],'variant'=>key[2],'cases'=>entries.size}.tap do |g|
    %w[reopen_ms stw_ms defrag_ms during_get_p99_ms during_get_max_ms during_put_ops_s].each do |field|
      values=entries.map { |r|r.fetch(field) }
      g[field]={'median'=>median(values),'min'=>values.min,'max'=>values.max}
    end
  end
end
File.write(File.join(root,'summary.json'),JSON.pretty_generate({'rows'=>rows,'groups'=>groups})+"\n")
puts JSON.pretty_generate(groups)
